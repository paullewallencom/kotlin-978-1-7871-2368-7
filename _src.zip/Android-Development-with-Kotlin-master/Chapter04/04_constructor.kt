    class Person { 
        var name: String 
        var age: Int 
 
        constructor(name: String, age: Int) { 
            this.name = name 
            this.age = age 
        }
	}
  fun main(args: Array<String>) {
	Person()
  }