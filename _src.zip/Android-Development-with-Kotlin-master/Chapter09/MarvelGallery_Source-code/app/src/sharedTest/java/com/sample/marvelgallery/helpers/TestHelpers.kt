package com.sample.marvelgallery.helpers

fun fail(): Nothing = throw Error("Assertion failed")
