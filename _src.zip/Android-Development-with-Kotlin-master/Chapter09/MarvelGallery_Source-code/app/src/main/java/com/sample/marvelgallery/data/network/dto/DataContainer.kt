package com.sample.marvelgallery.data.network.dto

class DataContainer<T> {
    var results: T? = null
}