package com.sample.marvelgallery.data.network.dto

class ListWrapper<T> {
    var items: List<T> = listOf()
}