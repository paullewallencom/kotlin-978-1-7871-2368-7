package com.sample.marvelgallery.data.network.dto

class OccurrenceDto {
    lateinit var name: String
}