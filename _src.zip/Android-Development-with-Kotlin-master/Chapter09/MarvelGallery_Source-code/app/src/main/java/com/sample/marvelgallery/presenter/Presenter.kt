package com.sample.marvelgallery.presenter

interface Presenter {
    fun onViewDestroyed()
}