package com.sample.marvelgallery.view.common

import android.support.v7.app.AppCompatActivity

abstract class BaseActivity: AppCompatActivity()