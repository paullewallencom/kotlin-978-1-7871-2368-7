package com.sample.marvelgallery.data.network.dto

class DataWrapper<T> {
    var data: DataContainer<T>? = null
}