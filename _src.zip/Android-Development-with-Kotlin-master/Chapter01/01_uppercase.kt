fun main(args: Array<String>) {
       val name = "Igor" 
        println("My name is ${name.toUpperCase()}") 
        // Prints: My name is IGOR 
}