fun main(args: Array<String>) {
	printSum(2,3)
}
fun printSum(a: Int, b: Int): Unit { 
    val sum = a + b 
    print(sum) 
}