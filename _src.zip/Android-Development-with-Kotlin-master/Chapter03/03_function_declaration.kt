fun main(args: Array<String>) {
	presentGently(42)
    presentGently("Pavan")
}
fun presentGently(v: Any) { 
	println("Hello. I would like to present you: $v") 
}