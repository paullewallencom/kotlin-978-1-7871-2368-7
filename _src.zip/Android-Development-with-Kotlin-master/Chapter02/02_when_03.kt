fun main(args: Array<String>) {
    val large:Boolean = true 
         
    when(large){ 
        true -> println("Big") 
        false -> println("Big") 
    } 
}