fun main(args: Array<String>) {
    val range = 1..6 
 
    for(i in range) { 
        print("$i ") 
    } 
}